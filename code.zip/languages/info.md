# Hello there! 👋


### This folder contains the language files of NekoTech Dash.


> [!WARNING]
> Note that files and translations may not be up-to-date during development and may be incomplete.


> [!NOTE]
> Last update occurred at: Never
