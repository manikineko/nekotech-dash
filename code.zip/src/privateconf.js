var PROXMOX_API_URL=  'http://proxmox.astralaxis.tech/api2/json';
var PROXMOX_TOKEN = 'API@pve!dash-app=7da2f4dc-e3e4-40ec-8594-778d84fee325';

export {PROXMOX_API_URL,PROXMOX_TOKEN};